"use strict";

const http = require("http");
const { create, update, list, get } = require("./zyte-engine");
const { renderHTML } = require("../render/zyte-render");
const { search } = require("./indexer");
const { createZox, listZox } = require("./zox-engine");
const { deterministicProof } = require("../proof/proof");
const { exportJSON, exportMarkdown } = require("../export/exporter");
const { getHistory } = require("./history-engine");
const { append, list: listChain } = require("./proofchain-engine");
const { bundle } = require("../bundle/bundler");
const { sign } = require("./signing-engine");
const { allow } = require("./ratelimit");
const fs = require("fs");
const path = require("path");

const LIMITS = path.join(__dirname, "../limits/limits.json");
const { max_body_bytes } = JSON.parse(fs.readFileSync(LIMITS, "utf8"));
const PORT = 9090;

function send(res, code, body, type="application/json") {
  res.writeHead(code, {
    "Content-Type": type,
    "Access-Control-Allow-Origin": "*",
    "Access-Control-Allow-Methods": "GET,POST,OPTIONS",
    "Access-Control-Allow-Headers": "Content-Type"
  });
  res.end(body);
}

function read(req, cb) {
  let b = "";
  let size = 0;
  req.on("data", c => {
    size += c.length;
    if (size > max_body_bytes) {
      req.destroy();
    } else {
      b += c;
    }
  });
  req.on("end", () => cb(b));
}

const server = http.createServer((req, res) => {
  const ip = req.socket.remoteAddress || "unknown";
  if (!allow(ip)) return send(res, 429, JSON.stringify({ error: "rate_limited" }));

  if (req.method === "OPTIONS") return send(res, 200, "");

  if (req.method === "GET" && req.url === "/zytes")
    return send(res, 200, JSON.stringify(list(), null, 2));

  if (req.method === "GET" && req.url.startsWith("/zyte/")) {
    const id = req.url.split("/").pop();
    const z = get(id);
    if (!z) return send(res, 404, "{}");
    return send(res, 200, JSON.stringify(z, null, 2));
  }

  if (req.method === "GET" && req.url.startsWith("/render/")) {
    const id = req.url.split("/").pop();
    const z = get(id);
    if (!z) return send(res, 404, "Not found", "text/plain");
    return send(res, 200, renderHTML(z), "text/html");
  }

  if (req.method === "GET" && req.url.startsWith("/search/")) {
    const term = decodeURIComponent(req.url.split("/").pop());
    return send(res, 200, JSON.stringify(search(term), null, 2));
  }

  if (req.method === "GET" && req.url === "/zox")
    return send(res, 200, JSON.stringify(listZox(), null, 2));

  if (req.method === "POST" && req.url === "/zox")
    return read(req, b => send(res, 201, JSON.stringify(createZox(...Object.values(JSON.parse(b))), null, 2)));

  if (req.method === "GET" && req.url.startsWith("/proof/")) {
    const id = req.url.split("/").pop();
    const z = get(id);
    if (!z) return send(res, 404, "{}");
    return send(res, 200, JSON.stringify({ id: z.id, proof: deterministicProof(z) }, null, 2));
  }

  if (req.method === "GET" && req.url.startsWith("/history/")) {
    const id = req.url.split("/").pop();
    return send(res, 200, JSON.stringify(getHistory(id), null, 2));
  }

  if (req.method === "GET" && req.url.startsWith("/export/json/")) {
    const id = req.url.split("/").pop();
    return send(res, 200, exportJSON(get(id)));
  }

  if (req.method === "GET" && req.url.startsWith("/export/md/")) {
    const id = req.url.split("/").pop();
    return send(res, 200, exportMarkdown(get(id)), "text/markdown");
  }

  if (req.method === "GET" && req.url.startsWith("/bundle/")) {
    const id = req.url.split("/").pop();
    const z = get(id);
    if (!z) return send(res, 404, "{}");
    const b = bundle(z, getHistory(id), deterministicProof(z), listZox());
    const signed = Object.assign({}, b, { signature: sign(b) });
    append({ type: "bundle", id });
    return send(res, 200, JSON.stringify(signed, null, 2));
  }

  if (req.method === "GET" && req.url === "/proofchain")
    return send(res, 200, JSON.stringify(listChain(), null, 2));

  if (req.method === "POST" && req.url === "/zyte")
    return read(req, b => send(res, 201, JSON.stringify(create(...Object.values(JSON.parse(b))), null, 2)));

  if (req.method === "POST" && req.url === "/zyte/update")
    return read(req, b => send(res, 200, JSON.stringify(update(...Object.values(JSON.parse(b))), null, 2)));

  send(res, 404, "{}");
});

server.listen(PORT, () => console.log("Zyte server v12 (Rate + Size limits) on " + PORT));
