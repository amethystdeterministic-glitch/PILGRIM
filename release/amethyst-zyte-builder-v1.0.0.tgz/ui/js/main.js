(function () {
"use strict";
var API = "http://127.0.0.1:9090";
function byId(i){return document.getElementById(i);}
function setText(e,t){if(e)e.textContent=t;}

function init(){
  var feed = byId("zyte-feed");
  var feedList = document.querySelector("#zyte-feed-content ul");

  feed.onclick = function(){
    var s = feed.getAttribute("data-state");
    feed.setAttribute("data-state", s==="expanded"?"collapsed":"expanded");
    if(s!=="expanded"){
      fetch(API+"/zytes").then(r=>r.json()).then(z=>{
        feedList.innerHTML="";
        z.forEach(i=>{
          var li=document.createElement("li");
          li.textContent=i.title+" v"+i.version;
          feedList.appendChild(li);
        });
      });
    }
  };

  byId("zb-create").onclick = function(){
    fetch(API+"/zyte",{method:"POST",headers:{"Content-Type":"application/json"},
      body:JSON.stringify({
        id:byId("zb-id").value,
        title:byId("zb-title").value,
        content:byId("zb-content").value
      })}).then(r=>r.json()).then(d=>setText(byId("zb-create-result"),JSON.stringify(d,null,2)));
  };

  byId("zox-bind").onclick = function(){
    fetch(API+"/zox",{method:"POST",headers:{"Content-Type":"application/json"},
      body:JSON.stringify({id:byId("zox-id").value,zyte:byId("zox-zyte").value})
    }).then(r=>r.json()).then(d=>setText(byId("zox-result"),JSON.stringify(d,null,2)));
  };

  byId("exp-json").onclick = function(){
    fetch(API+"/export/json/"+byId("exp-id").value)
      .then(r=>r.text()).then(t=>setText(byId("exp-result"),t));
  };

  byId("exp-md").onclick = function(){
    fetch(API+"/export/md/"+byId("exp-id").value)
      .then(r=>r.text()).then(t=>setText(byId("exp-result"),t));
  };
}

document.readyState==="loading"?document.addEventListener("DOMContentLoaded",init):init();
})();
