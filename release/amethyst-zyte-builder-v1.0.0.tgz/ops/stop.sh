#!/usr/bin/env bash
set -e

[ -f /tmp/zyte.pid ] && kill $(cat /tmp/zyte.pid) && rm /tmp/zyte.pid || true
[ -f /tmp/ui.pid ] && kill $(cat /tmp/ui.pid) && rm /tmp/ui.pid || true

echo "[+] Stopped"
