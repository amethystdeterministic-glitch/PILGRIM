#!/usr/bin/env bash
set -e

ROOT="$(cd "$(dirname "$0")/.." && pwd)"

echo "[+] Starting Zyte API"
node "$ROOT/zyte/runtime/zyte-server.js" >/tmp/zyte.log 2>&1 &
echo $! > /tmp/zyte.pid

echo "[+] Starting UI"
cd "$ROOT/ui"
python3 -m http.server 8080 >/tmp/ui.log 2>&1 &
echo $! > /tmp/ui.pid

sleep 1
echo "[+] OK"
echo "UI  : http://127.0.0.1:8080"
echo "API : http://127.0.0.1:9090"
