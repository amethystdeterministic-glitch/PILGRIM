import http from 'http';

const PORT = 8080;

const html = `
<!DOCTYPE html>
<html>
<head>
  <meta charset="UTF-8" />
  <title>Amethyst Portal</title>
  <style>
    body { background:#0b0f1a; color:#e6e9f0; font-family:system-ui; padding:24px; }
    .card { background:#121833; border-radius:16px; padding:20px; margin-bottom:16px; }
    .ok { color:#6cff8f; }
    .bad { color:#ff6c6c; }
  </style>
</head>
<body>
  <h1>Amethyst Portal</h1>

  <div class="card">
    <h2>System</h2>
    <div id="system">Checking…</div>
  </div>

  <div class="card">
    <h2>Source Head</h2>
    <div id="head">Checking…</div>
  </div>

  <div class="card">
    <h2>Source Verify</h2>
    <div id="verify">Checking…</div>
  </div>

<script>
(async () => {
  try {
    const r = await fetch('http://127.0.0.1:9190/api/source/status');
    const j = await r.json();

    document.getElementById('system').innerHTML =
      j.ok ? '<span class="ok">Available</span>' : '<span class="bad">Unavailable</span>';

    document.getElementById('head').innerHTML =
      j.ledger ? '<span class="ok">Ledger OK</span>' : '<span class="bad">Ledger Missing</span>';

    document.getElementById('verify').innerHTML =
      j.count > 0 ? '<span class="ok">Verified</span>' : '<span class="bad">Empty</span>';

  } catch (e) {
    document.getElementById('system').innerHTML = '<span class="bad">Unavailable</span>';
    document.getElementById('head').innerHTML = '<span class="bad">Unavailable</span>';
    document.getElementById('verify').innerHTML = '<span class="bad">Unavailable</span>';
  }
})();
</script>
</body>
</html>
`;

http.createServer((_req, res) => {
  res.writeHead(200, {
    'Content-Type': 'text/html',
    'Access-Control-Allow-Origin': '*'
  });
  res.end(html);
}).listen(PORT, () => {
  console.log('PORTAL listening on ' + PORT);
});
