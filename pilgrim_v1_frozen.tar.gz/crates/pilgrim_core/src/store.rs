#[derive(Debug, Clone, PartialEq, Eq)]
pub enum PrivacyTier {
    Public,
    Private,
    Sealed,
}
