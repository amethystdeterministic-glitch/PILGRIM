pub mod cartridge;

pub use cartridge::{Cartridge, CartridgeOutput};
